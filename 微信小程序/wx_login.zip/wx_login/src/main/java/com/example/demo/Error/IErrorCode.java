package com.example.demo.Error;

public interface IErrorCode {
    Integer getCode();

    String getMessage();
}
