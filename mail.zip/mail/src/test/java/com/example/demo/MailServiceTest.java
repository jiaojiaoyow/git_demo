package com.example.demo;

import com.example.demo.Service.MailService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MailServiceTest {

    @Autowired
    private MailService mailService;

    @Autowired
    private TemplateEngine templateEngine;

//    @Test
//    public void testSimpleMail() throws Exception {
//        mailService.sendSimpleMail("543648875@qq.com","test simple mail"," hello this is simple mail");
//    }

    //发送html格式邮件
    @Test
    public void sendTemplateMail() {
        //创建邮件正文
        Context context = new Context();
        context.setVariable("id", "006");
        String emailContent = templateEngine.process("email/email", context);

        mailService.sendHtmlMail("543648875@qq.com","主题：这是html模板邮件",emailContent);
    }
}